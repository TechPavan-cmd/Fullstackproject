import React from 'react';
import ReactDOM from 'react-dom';

const App = () => <h1>Hello from Frontend!</h1>;
ReactDOM.render(<App />, document.getElementById('root'));